<?php
	session_start();
	
	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
	header('location:../login.php');
    exit();
	}
	else{
	include('../conn.php');

	$query=mysqli_query($conn,"select * from `admin` where adID='".$_SESSION['id']."'");
	$row=mysqli_fetch_assoc($query);
	}
?>