<?php

$conn = new mysqli('localhost', 'root', '', 'sanjuan_cmacd_data');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>