
<?php include('headtag.php'); ?><body>
	<div class="grid">
	<div class="pre-loader">
		<div class="loader-logo"><img src="images/five.png" alt=""></div>
		<div id="ld4"></div>
		<div class="loading-text">
			Loading...
		</div>
	</div>
</div>
</body>